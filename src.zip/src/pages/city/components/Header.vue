<template>
    <div class="header">
        城市选择
    </div>
</template>

<script>
    export default{
        name:'CityHeader'
    }
</script>

<style lang="stylus" scoped>
    @import '~styles/varibles.styl'
    .header
        overflow:hidden
        height:.86rem
        line-height:.86rem
        text-align:center
        color:$bgColor
        font-size:.4rem

</style>