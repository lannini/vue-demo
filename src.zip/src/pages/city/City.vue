<template>
    <div>
        <city-header></city-header>
        wwww
    </div>>



</template>

<script>
    import CityHeader from './components/Header'
    export default{
        name:'City',
        components:{
            CityHeader
        }
    }
</script>

<style lang="stylus" scoped>


</style>